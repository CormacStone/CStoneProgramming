class Box:
  length = 0.0
  width = 0.0
  height = 0.0

  def __init__(self):
    self.length
    self.width
    self.height

  def volume(self):
    return self.length * self.width * self.height

  def surface_area(self):
    return 2 * (self.length * self.width + self.length * self.height +
                self.width * self.height)
