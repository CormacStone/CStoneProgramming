class Pyramid:
  length = 0
  width = 0
  height = 0

  def __init__(self):
    self.length
    self.width
    self.height

  def volume(self):
    return (self.length * self.width * self.height) / 3

  def surface_area(self):
    return (self.length * self.width) + (self.length * (
        (self.width / 2)**2 +
        (self.height**2))**0.5) + (self.width * ((self.length / 2)**2 +
                                                 (self.height**2))**0.5)
