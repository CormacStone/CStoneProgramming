class Sphere:
  radius = 0

  def __init__(self):
    self.radius

  def volume(self):
    return (4 / 3) * 3.14 * (self.radius**3)

  def surface_area(self):
    return 4 * 3.14 * (self.radius**2)
