from Box import Box
from Pyramid import Pyramid
from Sphere import Sphere

choice = input("if you like to build a box press 1, for a pyramid press 2, and for a sphere press 3. ")

if choice == "1":
  b1 = Box()
  b1.length = float(input("enter value for box length:"))
  b1.width = float(input("enter value for box width:"))
  b1.height = float(input("enter value for box height:"))

  print(b1.volume())
  print(b1.volume())
elif choice == "2":
  p1 = Pyramid()
  p1.length = float(input("enter value for pyramid length:"))
  p1.width = float(input("enter value for pyramid width:"))
  p1.height = float(input("enter value for pyramid height:"))

  print(p1.volume())
  print(p1.surface_area())
elif choice == "3":
  s1 = Sphere()
  s1.radius = float(input("enter value for sphere radius:"))

  print(s1.volume())
  print(s1.surface_area())
else : 
  print("invalid number, try again")